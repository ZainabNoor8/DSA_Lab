#include <iostream>
#include <algorithm>

struct Node {
    int key;
    Node* left;
    Node* right;
    int height;
};

// Function to calculate the height of a node
int getHeight(Node* node) {
    if (node == NULL) {
        return 0;
    }
    return node->height;
}

// Function to get the balance factor of a node
int getBalanceFactor(Node* node) {
    if (node == NULL) {
        return 0;
    }
    return getHeight(node->left) - getHeight(node->right);
}

// Function to create a new node
Node* createNode(int key) {
    Node* newNode = new Node;
    newNode->key = key;
    newNode->left = NULL;
    newNode->right = NULL;
    newNode->height = 1;
    return newNode;
}

// Function to perform a right rotation
Node* rightRotate(Node* y) {
    Node* x = y->left;
    Node* T2 = x->right;

    // Perform rotation
    x->right = y;
    y->left = T2;

    // Update heights
    y->height = 1 + std:: max(getHeight(y->left), getHeight(y->right));
    x->height = 1 + std::max(getHeight(x->left), getHeight(x->right));

    return x;
}

// Function to perform a left rotation
Node* leftRotate(Node* x) {
    Node* y = x->right;
    Node* T2 = y->left;

    // Perform rotation
    y->left = x;
    x->right = T2;

    // Update heights
    x->height = 1 + std::max(getHeight(x->left), getHeight(x->right));
    y->height = 1 + std::max(getHeight(y->left), getHeight(y->right));
    return y;
}

// Function to insert a key into an AVL tree
Node* insert(Node* root, int key) {
    if (root == NULL) {
        return createNode(key);
    }

    if (key < root->key) {
        root->left = insert(root->left, key);
    } else if (key > root->key) {
        root->right = insert(root->right, key);
    } else {
        
        return root;
    }

    // Update height
    root->height = 1 + std::max(getHeight(root->left), getHeight(root->right));

    // Get the balance factor
    int balance = getBalanceFactor(root);

    // Left Heavy
    if (balance > 1) {
        // Left-Left Case
        if (key < root->left->key) {
            return rightRotate(root);
        }
        // Left-Right Case
        else if (key > root->left->key) {
            root->left = leftRotate(root->left);
            return rightRotate(root);
        }
    }
    // Right Heavy
    else if (balance < -1) {
        // Right-Right Case
        if (key > root->right->key) {
            return leftRotate(root);
        }
        // Right-Left Case
        else if (key < root->right->key) {
            root->right = rightRotate(root->right);
            return leftRotate(root);
        }
    }

    return root;
}

// Function to find the node with the smallest key in the AVL tree
Node* findMin(Node* root) {
    while (root->left != NULL) {
        root = root->left;
    }
    return root;
}

// Function to delete a node with two children from an AVL tree
Node* deleteNode(Node* root, int key) {
    if (root == NULL) {
        return root;
    }

    if (key < root->key) {
        root->left = deleteNode(root->left, key);
    } else if (key > root->key) {
        root->right = deleteNode(root->right, key);
    } else {
        // Node with only one child or no child
        if (root->left == NULL || root->right == NULL) {
            Node* temp = root->left ? root->left : root->right;

            // No child case
            if (temp == NULL) {
                temp = root;
                root = NULL;
            } else {
                // One child case
                *root = *temp; // Copy the contents of the non-empty child
            }

            delete temp;
        } else {
            // Node with two children, get the inorder successor (smallest in the right subtree)
            Node* successor = findMin(root->right);

            // Copy the inorder successor's data to this node
            root->key = successor->key;

            // Delete the inorder successor
            root->right = deleteNode(root->right, successor->key);
        }
    }

    // If the tree had only one node, then return
    if (root == NULL) {
        return root;
    }

    // Update height
    root->height = 1 + std::max(getHeight(root->left), getHeight(root->right));

    // Get the balance factor
    int balance = getBalanceFactor(root);

    // Left Heavy
    if (balance > 1) {
        // Left-Left Case
        if (getBalanceFactor(root->left) >= 0) {
            return rightRotate(root);
        }
        // Left-Right Case
        else {
            root->left = leftRotate(root->left);
            return rightRotate(root);
        }
    }
    // Right Heavy
    else if (balance < -1) {
        // Right-Right Case
        if (getBalanceFactor(root->right) <= 0) {
            return leftRotate(root);
        }
        // Right-Left Case
        else {
            root->right = rightRotate(root->right);
            return leftRotate(root);
        }
    }

    return root;
}

// Function to print the inorder traversal of the AVL tree
void inOrderTraversal(Node* root) {
    if (root != NULL) {
        inOrderTraversal(root->left);
        std::cout << root->key << " ";
        inOrderTraversal(root->right);
    }
}

int main() {
    Node* root = NULL;

    // Insert nodes into the AVL tree
    root = insert(root, 15);
    root = insert(root, 12);
    root = insert(root, 54);
    root = insert(root, 8);
    root = insert(root, 13);
    root = insert(root, 5);
    root = insert(root, 9);
    root = insert(root, 14);
    root = insert(root, 18);
    root = insert(root,60);
    root = insert(root,16);
    root = insert(root,56);
    root = insert(root,70);

    std::cout << "Inorder traversal before deletion: ";
    inOrderTraversal(root);
    std::cout << std::endl;

    // Delete a node with two children
    root = deleteNode(root, 8);
    std::cout << "Inorder traversal after deletion: ";
    inOrderTraversal(root);
    root = deleteNode(root, 12);
    std::cout << "\nInorder traversal after deletion: ";
    inOrderTraversal(root);
    root = deleteNode(root, 54);
    std::cout << "\nInorder traversal after deletion: ";
    inOrderTraversal(root);
    std::cout << std::endl;


    return 0;
}

